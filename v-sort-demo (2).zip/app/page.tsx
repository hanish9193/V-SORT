import VSortApproachComparison from "@/components/v-sort-approach-comparison"

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <VSortApproachComparison />
    </main>
  )
}
