"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { X, Check, ArrowRight, Zap } from "lucide-react"

export default function VSortApproachComparison() {
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold text-gray-900">V-SORT's Approach: What Does the Paper Actually Say?</h1>
        <p className="text-lg text-gray-600">Understanding V-SORT's fundamental paradigm shift</p>
      </div>

      {/* The Two Approaches */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Traditional Approach - NOT used by V-SORT */}
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700">
              <X className="w-6 h-6" />
              Approach #1: Comparison-Based
            </CardTitle>
            <Badge variant="destructive" className="w-fit">
              NOT used by V-SORT
            </Badge>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white p-4 rounded-lg border border-red-200">
              <h4 className="font-semibold text-red-800 mb-2">The Question:</h4>
              <p className="text-red-700 italic">"Which element is smaller?"</p>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold text-red-800">How it works:</h4>
              <ul className="space-y-2 text-sm text-red-700">
                <li>• Compare elements pairwise</li>
                <li>• Make decisions based on comparisons</li>
                <li>• Recursively sort sub-arrays</li>
                <li>• O(n log n) time complexity</li>
              </ul>
            </div>

            <div className="bg-red-100 p-3 rounded border border-red-300">
              <p className="text-xs text-red-600">
                <strong>V-SORT Paper Quote:</strong> "V-SORT gets rid of both comparisons and specific for loops,
                changing them with fully vectorized GPU primitives"
              </p>
            </div>
          </CardContent>
        </Card>

        {/* V-SORT's Approach - Counting/Histogram */}
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-700">
              <Check className="w-6 h-6" />
              Approach #2: Counting/Histogram
            </CardTitle>
            <Badge variant="secondary" className="w-fit bg-green-100 text-green-800">
              ✅ V-SORT uses THIS approach
            </Badge>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white p-4 rounded-lg border border-green-200">
              <h4 className="font-semibold text-green-800 mb-2">The Question:</h4>
              <p className="text-green-700 italic">"How many of each value do we have?"</p>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold text-green-800">How it works:</h4>
              <ul className="space-y-2 text-sm text-green-700">
                <li>• Count frequency of each value</li>
                <li>• Build histogram distribution</li>
                <li>• Reconstruct sorted array</li>
                <li>• O(1) practical time complexity</li>
              </ul>
            </div>

            <div className="bg-green-100 p-3 rounded border border-green-300">
              <p className="text-xs text-green-600">
                <strong>V-SORT Paper Quote:</strong> "V-SORT employs vectorized operations—a histogram-based count
                followed by using a parallel growth using repeat"
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Clear Statement */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-800 flex items-center gap-2">
            <Zap className="w-6 h-6" />
            V-SORT's Explicit Statement
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-white p-4 rounded-lg border border-blue-200">
            <h4 className="font-semibold text-blue-800 mb-3">Direct Quotes from the Paper:</h4>
            <div className="space-y-3">
              <blockquote className="border-l-4 border-blue-400 pl-4 italic text-blue-700">
                "V-SORT gets rid of both comparisons and specific for loops, changing them with fully vectorized GPU
                primitives"
              </blockquote>
              <blockquote className="border-l-4 border-blue-400 pl-4 italic text-blue-700">
                "Unlike traditional techniques, V-SORT eliminates both comparisons and specific for loops"
              </blockquote>
              <blockquote className="border-l-4 border-blue-400 pl-4 italic text-blue-700">
                "V-SORT abandoning comparison in favor of mathematical mapping operations"
              </blockquote>
              <blockquote className="border-l-4 border-blue-400 pl-4 italic text-blue-700">
                "Rather than repeatedly asking the question 'which element is smaller?' V-SORT takes the problem as a
                question of 'where does each element belong?'"
              </blockquote>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* The Three Operations */}
      <Card>
        <CardHeader>
          <CardTitle>V-SORT's Three Vectorized Operations (No Comparisons)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="font-mono text-sm bg-gray-800 text-green-400 p-2 rounded mb-2">np.arange()</div>
              <h4 className="font-semibold text-gray-800">Step 1: Direct Index Mapping</h4>
              <p className="text-sm text-gray-600">Create array of all possible values</p>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="font-mono text-sm bg-gray-800 text-green-400 p-2 rounded mb-2">np.bincount()</div>
              <h4 className="font-semibold text-gray-800">Step 2: Histogram Counting</h4>
              <p className="text-sm text-gray-600">Count frequency of each value</p>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="font-mono text-sm bg-gray-800 text-green-400 p-2 rounded mb-2">np.repeat()</div>
              <h4 className="font-semibold text-gray-800">Step 3: Array Reconstruction</h4>
              <p className="text-sm text-gray-600">Rebuild sorted array from counts</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mathematical Transformation */}
      <Card className="bg-purple-50 border-purple-200">
        <CardHeader>
          <CardTitle className="text-purple-800">The Mathematical Transformation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded-lg border">
              <h4 className="font-semibold text-purple-800 mb-2">Traditional Sorting Problem:</h4>
              <p className="text-sm text-purple-700 mb-2">
                "Given array A, find permutation P such that A[P] is sorted"
              </p>
              <p className="text-xs text-purple-600 italic">Requires O(n log n) comparisons to determine P</p>
            </div>

            <div className="bg-white p-4 rounded-lg border">
              <h4 className="font-semibold text-purple-800 mb-2">V-SORT's Transformation:</h4>
              <p className="text-sm text-purple-700 mb-2">
                "Given frequency distribution F, directly construct sorted array S"
              </p>
              <p className="text-xs text-purple-600 italic">S = f(F) where F = histogram of input values</p>
            </div>
          </div>

          <div className="flex items-center justify-center">
            <ArrowRight className="w-8 h-8 text-purple-600" />
          </div>

          <div className="text-center bg-white p-4 rounded-lg border border-purple-200">
            <p className="font-semibold text-purple-800">
              Key Insight: For bounded integers, sorted array = f(frequency_distribution)
            </p>
            <p className="text-sm text-purple-600 mt-2">No comparisons needed - just counting and reconstruction!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
