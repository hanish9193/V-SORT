"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Zap, Clock, MemoryStickIcon as Memory, AlertTriangle } from "lucide-react"

export default function HistogramComparison() {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <h2 className="text-2xl font-bold text-center text-gray-900">Histogram-Based Sorting vs Traditional Sorting</h2>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Traditional Sorting */}
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="text-lg text-red-700">Traditional Comparison-Based Sorting</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-red-600" />
                <span className="text-sm">O(n log n) time complexity</span>
              </div>
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <span className="text-sm">Requires element-by-element comparisons</span>
              </div>
              <div className="flex items-center gap-2">
                <Memory className="w-4 h-4 text-red-600" />
                <span className="text-sm">Memory usage: O(n) or O(log n)</span>
              </div>
            </div>

            <div className="bg-red-50 p-3 rounded-lg">
              <h4 className="font-semibold text-red-800 mb-2">How it works:</h4>
              <ol className="text-sm text-red-700 space-y-1">
                <li>1. Compare elements pairwise</li>
                <li>2. Make decisions based on comparisons</li>
                <li>3. Recursively sort sub-arrays</li>
                <li>4. Merge or partition results</li>
              </ol>
            </div>

            <div className="space-y-2">
              <Badge variant="destructive">QuickSort: O(n²) worst case</Badge>
              <Badge variant="destructive">MergeSort: O(n) extra space</Badge>
              <Badge variant="destructive">HeapSort: Poor cache performance</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Histogram-Based Sorting */}
        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="text-lg text-green-700">Histogram-Based Sorting (V-SORT)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-green-600" />
                <span className="text-sm">O(1) practical time complexity</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-green-600" />
                <span className="text-sm">No comparisons needed</span>
              </div>
              <div className="flex items-center gap-2">
                <Memory className="w-4 h-4 text-green-600" />
                <span className="text-sm">Memory usage: O(range_size)</span>
              </div>
            </div>

            <div className="bg-green-50 p-3 rounded-lg">
              <h4 className="font-semibold text-green-800 mb-2">How it works:</h4>
              <ol className="text-sm text-green-700 space-y-1">
                <li>1. Count frequency of each value</li>
                <li>2. Build histogram (frequency distribution)</li>
                <li>3. Reconstruct array from histogram</li>
                <li>4. Done! No comparisons needed</li>
              </ol>
            </div>

            <div className="space-y-2">
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Vectorized operations
              </Badge>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                GPU acceleration
              </Badge>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Predictable performance
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Key Insight */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-800">💡 Key Insight: Why Histograms Enable O(1) Sorting</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-blue-700">
            The breakthrough insight is that{" "}
            <strong>
              for bounded integer data, the sorted array is completely determined by the frequency distribution
            </strong>
            .
          </p>
          <div className="grid md:grid-cols-2 gap-4 mt-4">
            <div className="bg-white p-3 rounded border">
              <h4 className="font-semibold text-blue-800">Traditional Approach:</h4>
              <p className="text-sm text-blue-600">"Which element is smaller?" (requires comparisons)</p>
            </div>
            <div className="bg-white p-3 rounded border">
              <h4 className="font-semibold text-blue-800">Histogram Approach:</h4>
              <p className="text-sm text-blue-600">"How many of each value do we have?" (just counting)</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* When to Use Each */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-700">✅ Use Histogram-Based Sorting When:</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li>• Data is bounded integers</li>
              <li>• Range size is small relative to data size</li>
              <li>• Many duplicate values</li>
              <li>• Performance is critical</li>
              <li>• GPU acceleration available</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-700">❌ Use Traditional Sorting When:</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li>• Data is not bounded integers</li>
              <li>• Range size is very large</li>
              <li>• Sparse data (few duplicates)</li>
              <li>• Memory is constrained</li>
              <li>• General-purpose sorting needed</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
