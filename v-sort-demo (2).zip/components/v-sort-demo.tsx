"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, RotateCcw, Zap } from "lucide-react"

interface SortStep {
  step: number
  title: string
  description: string
  input?: number[]
  output?: number[]
  operation: string
}

export default function VSortDemo() {
  const [currentStep, setCurrentStep] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const [inputArray] = useState([3, 1, 3, 0, 2, 1])

  const steps: SortStep[] = [
    {
      step: 0,
      title: "Input Array",
      description: "Starting with a bounded integer array",
      input: inputArray,
      operation: "Initial state",
    },
    {
      step: 1,
      title: "Step 1: Direct Index Mapping",
      description: "Create index array for all possible values (0 to max)",
      input: [0, 1, 2, 3],
      operation: "np.arange(min_val, max_val + 1)",
    },
    {
      step: 2,
      title: "Step 2: Occurrence Counting",
      description: "Count frequency of each value",
      input: [1, 2, 1, 2], // counts for [0,1,2,3]
      operation: "np.bincount(input_array)",
    },
    {
      step: 3,
      title: "Step 3: Array Reconstruction",
      description: "Repeat each value based on its count",
      output: [0, 1, 1, 2, 3, 3],
      operation: "np.repeat(indices, counts)",
    },
  ]

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setIsAnimating(true)
      setTimeout(() => {
        setCurrentStep(currentStep + 1)
        setIsAnimating(false)
      }, 300)
    }
  }

  const reset = () => {
    setCurrentStep(0)
    setIsAnimating(false)
  }

  const runAll = () => {
    setIsAnimating(true)
    let step = 0
    const interval = setInterval(() => {
      step++
      setCurrentStep(step)
      if (step >= steps.length - 1) {
        clearInterval(interval)
        setIsAnimating(false)
      }
    }, 800)
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold text-gray-900">V-SORT Algorithm Demo</h1>
        <p className="text-lg text-gray-600">Vectorized sorting for bounded integer datasets</p>
        <div className="flex justify-center gap-4">
          <Button onClick={nextStep} disabled={currentStep >= steps.length - 1 || isAnimating}>
            <Play className="w-4 h-4 mr-2" />
            Next Step
          </Button>
          <Button onClick={runAll} variant="outline" disabled={isAnimating}>
            <Zap className="w-4 h-4 mr-2" />
            Run All
          </Button>
          <Button onClick={reset} variant="outline">
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>
      </div>

      <Card className={`transition-all duration-300 ${isAnimating ? "scale-105 shadow-lg" : ""}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge variant="outline">Step {steps[currentStep].step}</Badge>
            {steps[currentStep].title}
          </CardTitle>
          <CardDescription>{steps[currentStep].description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <code className="text-sm font-mono text-blue-600">{steps[currentStep].operation}</code>
          </div>

          {steps[currentStep].input && (
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">
                {currentStep === 0
                  ? "Input Array:"
                  : currentStep === 1
                    ? "Index Array:"
                    : currentStep === 2
                      ? "Count Array:"
                      : "Data:"}
              </h4>
              <div className="flex gap-2 flex-wrap">
                {steps[currentStep].input!.map((value, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 bg-blue-100 border-2 border-blue-300 rounded-lg flex items-center justify-center font-bold text-blue-800 transition-all duration-200 hover:scale-110"
                  >
                    {value}
                  </div>
                ))}
              </div>
            </div>
          )}

          {steps[currentStep].output && (
            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-700">Sorted Output:</h4>
              <div className="flex gap-2 flex-wrap">
                {steps[currentStep].output!.map((value, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 bg-green-100 border-2 border-green-300 rounded-lg flex items-center justify-center font-bold text-green-800 transition-all duration-200 hover:scale-110"
                  >
                    {value}
                  </div>
                ))}
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-green-800 font-semibold">✅ Sorting Complete! Array [3,1,3,0,2,1] → [0,1,1,2,3,3]</p>
              <p className="text-sm text-green-600 mt-1">
                No comparisons needed - just direct mapping and vectorized operations!
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Key Advantages</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center gap-2">
              <Badge variant="secondary">O(1)</Badge>
              <span className="text-sm">Practical constant time for fixed ranges</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">Vectorized</Badge>
              <span className="text-sm">Leverages SIMD and GPU acceleration</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">No Comparisons</Badge>
              <span className="text-sm">Direct mapping eliminates comparison overhead</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Limitations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center gap-2">
              <Badge variant="destructive">Bounded Only</Badge>
              <span className="text-sm">Only works with bounded integers</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="destructive">Memory</Badge>
              <span className="text-sm">Memory scales with range size</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="destructive">Sparse Data</Badge>
              <span className="text-sm">Inefficient for large, sparse ranges</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
