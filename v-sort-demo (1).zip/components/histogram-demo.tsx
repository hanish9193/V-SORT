"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BarChart3, Play, RotateCcw, ArrowRight } from "lucide-react"

interface HistogramData {
  value: number
  count: number
  color: string
}

export default function HistogramDemo() {
  const [currentStep, setCurrentStep] = useState(0)
  const [inputArray] = useState([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 8, 9, 7, 9])
  const [isAnimating, setIsAnimating] = useState(false)

  // Calculate histogram data
  const histogramData: HistogramData[] = []
  const maxValue = Math.max(...inputArray)
  const colors = [
    "#ef4444",
    "#f97316",
    "#eab308",
    "#22c55e",
    "#06b6d4",
    "#3b82f6",
    "#8b5cf6",
    "#ec4899",
    "#f43f5e",
    "#84cc16",
  ]

  for (let i = 0; i <= maxValue; i++) {
    const count = inputArray.filter((val) => val === i).length
    histogramData.push({
      value: i,
      count,
      color: colors[i % colors.length],
    })
  }

  const steps = [
    {
      title: "Original Unsorted Array",
      description: "We start with an array of bounded integers",
      showArray: true,
      showHistogram: false,
      showSorted: false,
    },
    {
      title: "Building the Histogram",
      description: "Count frequency of each value (this is what np.bincount() does)",
      showArray: true,
      showHistogram: true,
      showSorted: false,
    },
    {
      title: "Histogram Complete",
      description: "Each bar shows how many times each value appears",
      showArray: false,
      showHistogram: true,
      showSorted: false,
    },
    {
      title: "Reconstructing Sorted Array",
      description: "Use histogram counts to rebuild array in sorted order",
      showArray: false,
      showHistogram: true,
      showSorted: true,
    },
  ]

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setIsAnimating(true)
      setTimeout(() => {
        setCurrentStep(currentStep + 1)
        setIsAnimating(false)
      }, 500)
    }
  }

  const reset = () => {
    setCurrentStep(0)
    setIsAnimating(false)
  }

  const runAll = () => {
    setIsAnimating(true)
    let step = 0
    const interval = setInterval(() => {
      step++
      setCurrentStep(step)
      if (step >= steps.length - 1) {
        clearInterval(interval)
        setIsAnimating(false)
      }
    }, 1200)
  }

  // Generate sorted array from histogram
  const sortedArray: number[] = []
  histogramData.forEach(({ value, count }) => {
    for (let i = 0; i < count; i++) {
      sortedArray.push(value)
    }
  })

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-2">
          <BarChart3 className="w-8 h-8 text-blue-600" />
          Histograms in V-SORT
        </h1>
        <p className="text-lg text-gray-600">Understanding how counting frequencies enables O(1) sorting</p>

        <div className="flex justify-center gap-4">
          <Button onClick={nextStep} disabled={currentStep >= steps.length - 1 || isAnimating}>
            <Play className="w-4 h-4 mr-2" />
            Next Step
          </Button>
          <Button onClick={runAll} variant="outline" disabled={isAnimating}>
            <BarChart3 className="w-4 h-4 mr-2" />
            Run All
          </Button>
          <Button onClick={reset} variant="outline">
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>
      </div>

      <Card className={`transition-all duration-500 ${isAnimating ? "scale-105 shadow-lg" : ""}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge variant="outline">Step {currentStep + 1}</Badge>
            {steps[currentStep].title}
          </CardTitle>
          <CardDescription>{steps[currentStep].description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Original Array */}
          {steps[currentStep].showArray && (
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-700">Input Array:</h4>
              <div className="flex gap-2 flex-wrap justify-center">
                {inputArray.map((value, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 bg-gray-100 border-2 border-gray-300 rounded-lg flex items-center justify-center font-bold text-gray-800 transition-all duration-300 hover:scale-110"
                    style={{
                      backgroundColor: `${colors[value % colors.length]}20`,
                      borderColor: colors[value % colors.length],
                    }}
                  >
                    {value}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Histogram */}
          {steps[currentStep].showHistogram && (
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-700">Frequency Histogram:</h4>
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-end justify-center gap-3 h-48">
                  {histogramData.map(({ value, count, color }) => (
                    <div key={value} className="flex flex-col items-center gap-2">
                      <div className="text-xs font-semibold text-gray-600">{count > 0 ? count : ""}</div>
                      <div
                        className="w-8 bg-opacity-80 rounded-t transition-all duration-700 flex items-end justify-center text-white text-xs font-bold"
                        style={{
                          backgroundColor: color,
                          height: `${Math.max(count * 30, count > 0 ? 20 : 0)}px`,
                          opacity: currentStep >= 1 ? 1 : 0.3,
                        }}
                      ></div>
                      <div className="text-sm font-semibold text-gray-700">{value}</div>
                    </div>
                  ))}
                </div>
                <div className="text-center text-xs text-gray-500 mt-2">Values (x-axis) → Frequency Count (y-axis)</div>
              </div>
            </div>
          )}

          {/* Arrow */}
          {steps[currentStep].showSorted && (
            <div className="flex justify-center">
              <ArrowRight className="w-8 h-8 text-blue-600 animate-pulse" />
            </div>
          )}

          {/* Sorted Array */}
          {steps[currentStep].showSorted && (
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-700">Reconstructed Sorted Array:</h4>
              <div className="flex gap-2 flex-wrap justify-center">
                {sortedArray.map((value, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 bg-green-100 border-2 border-green-400 rounded-lg flex items-center justify-center font-bold text-green-800 transition-all duration-300 hover:scale-110 animate-fadeIn"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    {value}
                  </div>
                ))}
              </div>
              <div className="text-center text-sm text-green-600 font-semibold">✅ Sorted without any comparisons!</div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Explanation Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              What is a Histogram?
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-gray-600">
              A histogram is a graphical representation showing the frequency distribution of data.
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge variant="secondary">X-axis</Badge>
                <span className="text-sm">Possible values (0, 1, 2, 3...)</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">Y-axis</Badge>
                <span className="text-sm">Frequency count (how many times each value appears)</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">Bars</Badge>
                <span className="text-sm">Height represents frequency</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">How V-SORT Uses Histograms</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-gray-600">
              V-SORT uses histograms to transform sorting into a counting problem.
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge variant="outline">1</Badge>
                <span className="text-sm">Count frequency of each value</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">2</Badge>
                <span className="text-sm">Build histogram (frequency distribution)</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">3</Badge>
                <span className="text-sm">Reconstruct sorted array from histogram</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Code Example */}
      <Card>
        <CardHeader>
          <CardTitle>Python Implementation</CardTitle>
          <CardDescription>How np.bincount() creates the histogram</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm overflow-x-auto">
            <div className="space-y-2">
              <div>
                <span className="text-blue-400">import</span> <span className="text-green-400">numpy</span>{" "}
                <span className="text-blue-400">as</span> <span className="text-green-400">np</span>
              </div>
              <div></div>
              <div>
                <span className="text-gray-500"># Input array</span>
              </div>
              <div>
                <span className="text-yellow-400">arr</span> ={" "}
                <span className="text-green-400">[3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]</span>
              </div>
              <div></div>
              <div>
                <span className="text-gray-500"># Create histogram using bincount</span>
              </div>
              <div>
                <span className="text-yellow-400">histogram</span> = <span className="text-green-400">np.bincount</span>
                (<span className="text-yellow-400">arr</span>)
              </div>
              <div>
                <span className="text-gray-500"># Result: [0, 2, 1, 2, 1, 3, 1, 0, 0, 1]</span>
              </div>
              <div>
                <span className="text-gray-500"># ^ ^ ^ ^ ^ ^ ^ ^ ^ ^</span>
              </div>
              <div>
                <span className="text-gray-500"># 0 1 2 3 4 5 6 7 8 9</span>
              </div>
              <div></div>
              <div>
                <span className="text-gray-500"># Reconstruct sorted array</span>
              </div>
              <div>
                <span className="text-yellow-400">indices</span> = <span className="text-green-400">np.arange</span>(
                <span className="text-purple-400">len</span>(<span className="text-yellow-400">histogram</span>))
              </div>
              <div>
                <span className="text-yellow-400">sorted_arr</span> = <span className="text-green-400">np.repeat</span>(
                <span className="text-yellow-400">indices</span>, <span className="text-yellow-400">histogram</span>)
              </div>
              <div>
                <span className="text-gray-500"># Result: [1, 1, 2, 3, 3, 4, 5, 5, 5, 6, 9]</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
