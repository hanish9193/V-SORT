import HistogramDemo from "@/components/histogram-demo"
import HistogramComparison from "@/components/histogram-comparison"

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <HistogramDemo />
      <div className="my-12 border-t border-gray-200"></div>
      <HistogramComparison />
    </main>
  )
}
